# Logs

- `logs/simulated/` contains simulated reference logs prepared from the manuscript results.
- Real execution logs should be saved under `logs/real/` or exported from the execution environment.
- Do not mix simulated and real logs in the same directory.
