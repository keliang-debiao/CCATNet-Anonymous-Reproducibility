# Simulated Reference Logs

These logs are simulated examples based on the manuscript result tables. They are included to show expected formatting for AI-guided reproduction and anonymous review packaging. They are not empirical runtime logs.

Replace every file in this folder with real logs generated from the public Kaggle datasets before final public release.

