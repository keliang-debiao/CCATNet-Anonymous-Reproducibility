from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass
class ExperimentConfig:
    raw: dict[str, Any]
    path: Path

    @property
    def seed(self) -> int:
        return int(self.raw["project"]["seed"])

    @property
    def output_dir(self) -> Path:
        return Path(self.raw["project"]["output_dir"])


def load_config(path: str | Path) -> ExperimentConfig:
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    return ExperimentConfig(raw=raw, path=path)


def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path

