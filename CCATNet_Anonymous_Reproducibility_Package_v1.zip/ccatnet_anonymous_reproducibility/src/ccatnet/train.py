from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from .metrics import choose_threshold, evaluate_binary
from .model import CCATNet


@dataclass
class TrainResult:
    metrics: dict[str, float]
    threshold: float
    probabilities: np.ndarray


def set_seed(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def country_codes(country: pd.Series) -> tuple[np.ndarray, dict[str, int]]:
    values = country.fillna("Unknown").astype(str).to_numpy()
    vocab = {"Unknown": 0}
    for value in sorted(set(values)):
        if value not in vocab:
            vocab[value] = len(vocab)
    return np.asarray([vocab[v] for v in values], dtype=np.int64), vocab


def map_country_codes(country: pd.Series, vocab: dict[str, int]) -> np.ndarray:
    values = country.fillna("Unknown").astype(str).to_numpy()
    unk = vocab.get("Unknown", 0)
    return np.asarray([vocab.get(v, unk) for v in values], dtype=np.int64)


def _to_dense(x):
    return x.toarray() if hasattr(x, "toarray") else np.asarray(x)


def train_ccatnet(
    x_train,
    y_train,
    country_train,
    x_valid,
    y_valid,
    country_valid,
    model_cfg: dict,
    seed: int,
    device: str = "cpu",
) -> TrainResult:
    set_seed(seed)
    x_train = _to_dense(x_train).astype("float32")
    x_valid = _to_dense(x_valid).astype("float32")
    y_train = np.asarray(y_train).astype("float32")
    y_valid = np.asarray(y_valid).astype("int64")
    c_train, vocab = country_codes(pd.Series(country_train))
    c_valid = map_country_codes(pd.Series(country_valid), vocab)
    model = CCATNet(
        input_dim=x_train.shape[1],
        n_countries=max(len(vocab), 1),
        embedding_dim=int(model_cfg["embedding_dim"]),
        encoder_blocks=int(model_cfg["encoder_blocks"]),
        experts=int(model_cfg["experts"]),
        retrieval_temperature=float(model_cfg["retrieval_temperature"]),
        dropout=float(model_cfg["dropout"]),
    ).to(device)
    y_tensor = torch.tensor(y_train, dtype=torch.float32)
    pos = max(float(y_tensor.sum()), 1.0)
    neg = max(float(len(y_tensor) - y_tensor.sum()), 1.0)
    pos_weight = torch.tensor([neg / pos], dtype=torch.float32, device=device)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    opt = torch.optim.AdamW(
        model.parameters(),
        lr=float(model_cfg["learning_rate"]),
        weight_decay=float(model_cfg["weight_decay"]),
    )
    ds = TensorDataset(
        torch.tensor(x_train),
        torch.tensor(c_train),
        torch.tensor(y_train),
    )
    loader = DataLoader(ds, batch_size=int(model_cfg["batch_size"]), shuffle=True)
    max_epochs = min(int(model_cfg["max_epochs"]), 12)
    for _ in range(max_epochs):
        model.train()
        for xb, cb, yb in loader:
            xb, cb, yb = xb.to(device), cb.to(device), yb.to(device)
            opt.zero_grad()
            with torch.no_grad():
                batch_bank = model.encode(xb, cb).detach()
            logits, pi = model(xb, cb, bank=batch_bank)
            main_loss = loss_fn(logits, yb)
            balance_loss = torch.mean(torch.sum(pi * torch.log(pi.clamp_min(1e-8)), dim=-1))
            loss = main_loss + float(model_cfg["loss_weights"]["balance"]) * balance_loss
            loss.backward()
            opt.step()
    model.eval()
    with torch.no_grad():
        train_bank = model.encode(
            torch.tensor(x_train, dtype=torch.float32, device=device),
            torch.tensor(c_train, dtype=torch.long, device=device),
        ).detach()
        logits, _ = model(
            torch.tensor(x_valid, dtype=torch.float32, device=device),
            torch.tensor(c_valid, dtype=torch.long, device=device),
            bank=train_bank,
        )
        probs = torch.sigmoid(logits).cpu().numpy()
    threshold = choose_threshold(y_valid, probs, metric="f1")
    metrics = evaluate_binary(y_valid, probs, threshold=threshold)
    return TrainResult(metrics=metrics, threshold=threshold, probabilities=probs)
