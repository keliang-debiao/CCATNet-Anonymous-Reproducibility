from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


@dataclass
class PreparedFrame:
    frame: pd.DataFrame
    label: pd.Series
    country: pd.Series
    feature_columns: list[str]


def _first_existing(columns: Iterable[str], candidates: Iterable[str]) -> str | None:
    lookup = {c.lower(): c for c in columns}
    for c in candidates:
        if c.lower() in lookup:
            return lookup[c.lower()]
    return None


def derive_label(series: pd.Series, positive_patterns: list[str], negative_patterns: list[str]) -> pd.Series:
    text = series.astype(str).str.lower()
    y = pd.Series(np.nan, index=series.index, dtype=float)
    pos = np.zeros(len(series), dtype=bool)
    neg = np.zeros(len(series), dtype=bool)
    for p in positive_patterns:
        pos |= text.str.contains(p, regex=False).to_numpy()
    for p in negative_patterns:
        neg |= text.str.contains(p, regex=False).to_numpy()
    y[pos & ~neg] = 1.0
    y[neg] = 0.0
    return y


def screen_leakage_columns(columns: list[str], leakage_keywords: list[str], label_col: str) -> list[str]:
    keep = []
    lowered_keywords = [k.lower() for k in leakage_keywords]
    for col in columns:
        low = col.lower()
        if col == label_col:
            continue
        if any(k in low for k in lowered_keywords):
            continue
        keep.append(col)
    return keep


def load_stackoverflow_csv(path: str | Path, cfg: dict) -> PreparedFrame:
    path = Path(path)
    df = pd.read_csv(path, low_memory=False)
    label_col = _first_existing(df.columns, cfg["label_column_candidates"])
    if label_col is None:
        raise ValueError(f"No label column found in {path}. Configure label_column_candidates.")
    country_col = _first_existing(df.columns, cfg["country_column_candidates"])
    if country_col is None:
        raise ValueError(f"No country column found in {path}. Configure country_column_candidates.")
    y = derive_label(
        df[label_col],
        cfg["target_positive_patterns"],
        cfg["target_negative_patterns"],
    )
    valid = y.notna()
    df = df.loc[valid].reset_index(drop=True)
    y = y.loc[valid].astype(int).reset_index(drop=True)
    country = df[country_col].fillna("Unknown").astype(str).reset_index(drop=True)
    feature_columns = screen_leakage_columns(
        list(df.columns),
        leakage_keywords=cfg["leakage_keywords"],
        label_col=label_col,
    )
    return PreparedFrame(df[feature_columns].copy(), y, country, feature_columns)


def harmonize_frames(dev: PreparedFrame, ext: PreparedFrame) -> tuple[PreparedFrame, PreparedFrame]:
    common = [c for c in dev.feature_columns if c in set(ext.feature_columns)]
    return (
        PreparedFrame(dev.frame[common].copy(), dev.label, dev.country, common),
        PreparedFrame(ext.frame[common].copy(), ext.label, ext.country, common),
    )


def infer_column_types(frame: pd.DataFrame) -> tuple[list[str], list[str]]:
    numeric = []
    categorical = []
    for col in frame.columns:
        if pd.api.types.is_numeric_dtype(frame[col]):
            numeric.append(col)
        else:
            categorical.append(col)
    return numeric, categorical


def build_preprocessor(frame: pd.DataFrame) -> ColumnTransformer:
    numeric, categorical = infer_column_types(frame)
    num_pipe = Pipeline(
        steps=[
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]
    )
    cat_pipe = Pipeline(
        steps=[
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", min_frequency=20)),
        ]
    )
    return ColumnTransformer(
        transformers=[
            ("num", num_pipe, numeric),
            ("cat", cat_pipe, categorical),
        ],
        sparse_threshold=0.3,
    )


def make_folds(y: pd.Series, n_splits: int, seed: int):
    splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(splitter.split(np.zeros(len(y)), y.to_numpy()))
