from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F


class BehaviorSemanticTokenizer(nn.Module):
    """Dense feature tokenizer for preprocessed tabular vectors.

    The manuscript describes feature identity, value, and missingness embeddings.
    The public scaffold receives fold-specific preprocessed numeric arrays and
    implements a compact equivalent token projection.
    """

    def __init__(self, input_dim: int, embedding_dim: int):
        super().__init__()
        self.feature_embedding = nn.Parameter(torch.randn(input_dim, embedding_dim) * 0.02)
        self.value_scale = nn.Parameter(torch.randn(input_dim, embedding_dim) * 0.02)
        self.bias = nn.Parameter(torch.zeros(input_dim, embedding_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.feature_embedding.unsqueeze(0) + x.unsqueeze(-1) * self.value_scale.unsqueeze(0) + self.bias


class TabularEncoder(nn.Module):
    def __init__(self, embedding_dim: int, blocks: int, dropout: float):
        super().__init__()
        layers = []
        for _ in range(blocks):
            layers.append(
                nn.Sequential(
                    nn.LayerNorm(embedding_dim),
                    nn.Linear(embedding_dim, embedding_dim * 2),
                    nn.GELU(),
                    nn.Dropout(dropout),
                    nn.Linear(embedding_dim * 2, embedding_dim),
                )
            )
        self.layers = nn.ModuleList(layers)

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        h = tokens
        for layer in self.layers:
            h = h + layer(h)
        return h.mean(dim=1)


class CountryPrototypeAdapter(nn.Module):
    def __init__(self, n_countries: int, embedding_dim: int):
        super().__init__()
        self.prototypes = nn.Embedding(n_countries, embedding_dim)
        self.gate = nn.Linear(embedding_dim * 2, embedding_dim)
        self.proj = nn.Linear(embedding_dim, embedding_dim)

    def forward(self, h: torch.Tensor, country_id: torch.Tensor) -> torch.Tensor:
        q = self.prototypes(country_id)
        alpha = torch.sigmoid(self.gate(torch.cat([h, q], dim=-1)))
        return h + alpha * self.proj(q)


class BalancedEvidenceRetriever(nn.Module):
    """Training-bank retrieval scaffold.

    In full reproduction, the representation bank should be frozen from the
    corresponding training fold. In demo mode, the bank is set from the current
    mini-batch to keep the script lightweight.
    """

    def __init__(self, embedding_dim: int, temperature: float = 0.10):
        super().__init__()
        self.temperature = temperature
        self.fallback = nn.Parameter(torch.zeros(embedding_dim))

    def forward(self, h: torch.Tensor, bank: torch.Tensor | None = None) -> torch.Tensor:
        if bank is None or bank.numel() == 0:
            return self.fallback.unsqueeze(0).expand_as(h)
        h_norm = F.normalize(h, dim=-1)
        b_norm = F.normalize(bank, dim=-1)
        sim = h_norm @ b_norm.t()
        weights = torch.softmax(sim / self.temperature, dim=-1)
        return weights @ bank


class BehaviorRegimeMixture(nn.Module):
    def __init__(self, embedding_dim: int, experts: int, dropout: float):
        super().__init__()
        self.experts = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(embedding_dim * 2, embedding_dim),
                    nn.GELU(),
                    nn.Dropout(dropout),
                    nn.Linear(embedding_dim, embedding_dim),
                )
                for _ in range(experts)
            ]
        )
        self.router = nn.Linear(embedding_dim * 2, experts)

    def forward(self, h: torch.Tensor, e: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        x = torch.cat([h, e], dim=-1)
        pi = torch.softmax(self.router(x), dim=-1)
        expert_out = torch.stack([expert(x) for expert in self.experts], dim=1)
        z = torch.sum(pi.unsqueeze(-1) * expert_out, dim=1)
        return z, pi


class CCATNet(nn.Module):
    def __init__(
        self,
        input_dim: int,
        n_countries: int,
        embedding_dim: int = 128,
        encoder_blocks: int = 3,
        experts: int = 4,
        retrieval_temperature: float = 0.10,
        dropout: float = 0.15,
    ):
        super().__init__()
        self.tokenizer = BehaviorSemanticTokenizer(input_dim, embedding_dim)
        self.encoder = TabularEncoder(embedding_dim, encoder_blocks, dropout)
        self.country_adapter = CountryPrototypeAdapter(n_countries, embedding_dim)
        self.retriever = BalancedEvidenceRetriever(embedding_dim, retrieval_temperature)
        self.mixture = BehaviorRegimeMixture(embedding_dim, experts, dropout)
        self.head = nn.Linear(embedding_dim, 1)

    def encode(self, x: torch.Tensor, country_id: torch.Tensor) -> torch.Tensor:
        tokens = self.tokenizer(x)
        h = self.encoder(tokens)
        return self.country_adapter(h, country_id)

    def forward(
        self,
        x: torch.Tensor,
        country_id: torch.Tensor,
        bank: torch.Tensor | None = None,
        temperature: float = 1.0,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        h = self.encode(x, country_id)
        e = self.retriever(h, bank=bank)
        z, pi = self.mixture(h, e)
        logits = self.head(z).squeeze(-1) / temperature
        return logits, pi

