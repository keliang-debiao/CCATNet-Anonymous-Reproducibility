from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    f1_score,
    roc_auc_score,
)


def expected_calibration_error(y_true, y_prob, n_bins: int = 15) -> float:
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob).astype(float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    for lo, hi in zip(bins[:-1], bins[1:]):
        mask = (y_prob >= lo) & (y_prob < hi)
        if hi == 1.0:
            mask = (y_prob >= lo) & (y_prob <= hi)
        if not np.any(mask):
            continue
        conf = float(np.mean(y_prob[mask]))
        acc = float(np.mean(y_true[mask]))
        ece += float(np.mean(mask)) * abs(acc - conf)
    return ece


def evaluate_binary(y_true, y_prob, threshold: float = 0.5, n_bins: int = 15) -> dict[str, float]:
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob).astype(float)
    y_hat = (y_prob >= threshold).astype(int)
    return {
        "AUROC": float(roc_auc_score(y_true, y_prob)),
        "AUPRC": float(average_precision_score(y_true, y_prob)),
        "F1": float(f1_score(y_true, y_hat)),
        "Brier": float(brier_score_loss(y_true, y_prob)),
        "ECE": float(expected_calibration_error(y_true, y_prob, n_bins=n_bins)),
    }


def choose_threshold(y_true, y_prob, metric: str = "f1") -> float:
    if metric != "f1":
        raise ValueError("Only F1 threshold selection is implemented in this scaffold.")
    grid = np.linspace(0.05, 0.95, 181)
    scores = [f1_score(y_true, np.asarray(y_prob) >= t) for t in grid]
    return float(grid[int(np.argmax(scores))])


def summarize_folds(rows: list[dict[str, float]]) -> dict[str, tuple[float, float]]:
    out: dict[str, tuple[float, float]] = {}
    keys = [k for k in rows[0] if k.lower() not in {"fold", "threshold", "model"}]
    for k in keys:
        try:
            vals = np.asarray([row[k] for row in rows], dtype=float)
        except (TypeError, ValueError):
            continue
        out[k] = (float(vals.mean()), float(vals.std(ddof=1)))
    return out
