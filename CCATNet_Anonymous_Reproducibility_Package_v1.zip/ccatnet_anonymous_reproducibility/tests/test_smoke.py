from __future__ import annotations

import numpy as np
import pandas as pd

from ccatnet.data import build_preprocessor, load_stackoverflow_csv, make_folds
from ccatnet.metrics import evaluate_binary
from ccatnet.train import train_ccatnet


def test_metric_computation_is_stable() -> None:
    y = np.array([0, 0, 1, 1])
    p = np.array([0.10, 0.40, 0.70, 0.90])
    metrics = evaluate_binary(y, p, threshold=0.5)
    assert metrics["AUROC"] == 1.0
    assert metrics["AUPRC"] == 1.0
    assert metrics["F1"] == 1.0
    assert 0.0 <= metrics["ECE"] <= 1.0


def test_preprocessing_and_model_smoke(tmp_path) -> None:
    n = 80
    rng = np.random.default_rng(2026)
    frame = pd.DataFrame(
        {
            "Country": rng.choice(["United States", "India", "Germany"], size=n),
            "DevType": rng.choice(["Developer", "Student"], size=n),
            "YearsCodePro": rng.normal(8, 3, size=n).clip(0),
            "RemoteWork": rng.choice(["Remote", "Hybrid"], size=n),
            "AISelect": np.where(np.arange(n) % 3 == 0, "No, do not plan to use", "Yes, currently using"),
            "AI Trust": rng.choice(["High", "Low"], size=n),
        }
    )
    path = tmp_path / "demo.csv"
    frame.to_csv(path, index=False)
    cfg = {
        "label_column_candidates": ["AISelect"],
        "country_column_candidates": ["Country"],
        "target_positive_patterns": ["yes", "currently", "plan", "using"],
        "target_negative_patterns": ["no", "do not", "not plan"],
        "leakage_keywords": ["ai trust"],
    }
    prepared = load_stackoverflow_csv(path, cfg)
    folds = make_folds(prepared.label, 2, seed=2026)
    tr, va = folds[0]
    pre = build_preprocessor(prepared.frame.iloc[tr])
    x_tr = pre.fit_transform(prepared.frame.iloc[tr])
    x_va = pre.transform(prepared.frame.iloc[va])
    model_cfg = {
        "embedding_dim": 16,
        "encoder_blocks": 1,
        "experts": 2,
        "retrieval_temperature": 0.10,
        "dropout": 0.05,
        "learning_rate": 0.001,
        "weight_decay": 0.0001,
        "batch_size": 16,
        "max_epochs": 2,
        "loss_weights": {"balance": 0.01},
    }
    result = train_ccatnet(
        x_tr,
        prepared.label.iloc[tr].to_numpy(),
        prepared.country.iloc[tr],
        x_va,
        prepared.label.iloc[va].to_numpy(),
        prepared.country.iloc[va],
        model_cfg,
        seed=2026,
    )
    assert set(["AUROC", "AUPRC", "F1", "Brier", "ECE"]).issubset(result.metrics)
    assert result.probabilities.shape[0] == len(va)
