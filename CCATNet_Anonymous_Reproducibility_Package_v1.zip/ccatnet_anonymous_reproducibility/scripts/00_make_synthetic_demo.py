#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def make_frame(n: int, year: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    countries = np.array(["United States", "India", "Germany", "Brazil", "Japan", "United Kingdom"])
    roles = np.array(["Developer", "Student", "Manager", "Researcher"])
    edu = np.array(["Bachelor", "Master", "Doctoral", "Other"])
    country = rng.choice(countries, size=n, p=[0.32, 0.22, 0.14, 0.12, 0.10, 0.10])
    role = rng.choice(roles, size=n)
    education = rng.choice(edu, size=n)
    years_code = rng.gamma(shape=3.0, scale=4.0, size=n).clip(0, 45)
    remote = rng.choice(["Remote", "Hybrid", "In-person"], size=n)
    salary = rng.lognormal(mean=10.6, sigma=0.6, size=n)
    country_effect = np.isin(country, ["United States", "India", "Germany"]).astype(float) * 0.35
    year_effect = 0.35 if year == 2025 else 0.0
    logit = -0.25 + 0.05 * years_code + country_effect + 0.25 * (role == "Developer") + year_effect
    prob = 1 / (1 + np.exp(-logit))
    label = rng.binomial(1, prob)
    text = np.where(label == 1, "Yes, currently using or plan to use", "No, do not plan to use")
    # Include leakage-like columns so screening behavior can be inspected.
    ai_trust = np.where(label == 1, "High AI trust", "Low AI trust")
    return pd.DataFrame(
        {
            "Country": country,
            "DevType": role,
            "EdLevel": education,
            "YearsCodePro": years_code.round(2),
            "RemoteWork": remote,
            "ConvertedCompYearly": salary.round(2),
            "AISelect": text,
            "AI Trust": ai_trust,
        }
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="data/processed/demo")
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    make_frame(900, 2024, 2024).to_csv(out / "so_2024_demo.csv", index=False)
    make_frame(600, 2025, 2025).to_csv(out / "so_2025_demo.csv", index=False)
    print(f"wrote demo CSVs to {out}")


if __name__ == "__main__":
    main()
