#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ccatnet.config import load_config, ensure_dir
from ccatnet.data import build_preprocessor, load_stackoverflow_csv, make_folds
from ccatnet.metrics import choose_threshold, evaluate_binary, summarize_folds


def resolve_dev_path(cfg, demo: bool) -> Path:
    if demo:
        return Path(cfg.raw["data"]["demo_dir"]) / "so_2024_demo.csv"
    return Path(cfg.raw["data"]["development_csv"])


def to_dense(x):
    return x.toarray() if hasattr(x, "toarray") else np.asarray(x)


def probability(model, x) -> np.ndarray:
    if hasattr(model, "predict_proba"):
        return model.predict_proba(x)[:, 1]
    score = model.decision_function(x)
    return 1.0 / (1.0 + np.exp(-score))


def model_factories(seed: int) -> dict[str, Callable[[], object]]:
    from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
    from sklearn.linear_model import LogisticRegression

    factories: dict[str, Callable[[], object]] = {
        "Logistic Regression": lambda: LogisticRegression(
            max_iter=1000,
            class_weight="balanced",
            solver="lbfgs",
        ),
        "Random Forest": lambda: RandomForestClassifier(
            n_estimators=300,
            min_samples_leaf=5,
            class_weight="balanced_subsample",
            n_jobs=-1,
            random_state=seed,
        ),
        "HistGradientBoosting": lambda: HistGradientBoostingClassifier(
            max_iter=300,
            learning_rate=0.05,
            l2_regularization=0.01,
            random_state=seed,
        ),
    }
    try:
        from xgboost import XGBClassifier

        factories["XGBoost"] = lambda: XGBClassifier(
            n_estimators=300,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.85,
            colsample_bytree=0.85,
            objective="binary:logistic",
            eval_metric="logloss",
            n_jobs=-1,
            random_state=seed,
        )
    except Exception:
        pass
    try:
        from lightgbm import LGBMClassifier

        factories["LightGBM"] = lambda: LGBMClassifier(
            n_estimators=400,
            num_leaves=31,
            learning_rate=0.04,
            subsample=0.85,
            colsample_bytree=0.85,
            random_state=seed,
            verbose=-1,
        )
    except Exception:
        pass
    try:
        from catboost import CatBoostClassifier

        factories["CatBoost"] = lambda: CatBoostClassifier(
            iterations=400,
            depth=6,
            learning_rate=0.04,
            loss_function="Logloss",
            verbose=False,
            random_seed=seed,
        )
    except Exception:
        pass
    return factories


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/ccatnet_so2024.yaml")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    cfg = load_config(args.config)
    frame = load_stackoverflow_csv(resolve_dev_path(cfg, args.demo), cfg.raw["data"])
    folds = make_folds(frame.label, cfg.raw["data"]["n_splits"], cfg.seed)
    rows: list[dict[str, object]] = []
    for model_name, factory in model_factories(cfg.seed).items():
        for fold, (tr, va) in enumerate(folds, 1):
            pre = build_preprocessor(frame.frame.iloc[tr])
            x_tr = pre.fit_transform(frame.frame.iloc[tr])
            x_va = pre.transform(frame.frame.iloc[va])
            if model_name in {"HistGradientBoosting", "CatBoost"}:
                x_tr = to_dense(x_tr)
                x_va = to_dense(x_va)
            model = factory()
            model.fit(x_tr, frame.label.iloc[tr].to_numpy())
            probs = probability(model, x_va)
            threshold = choose_threshold(frame.label.iloc[va].to_numpy(), probs, metric="f1")
            metrics = evaluate_binary(frame.label.iloc[va].to_numpy(), probs, threshold=threshold)
            row = {"Model": model_name, "Fold": fold, "Threshold": threshold, **metrics}
            rows.append(row)
            print(f"model={model_name} fold={fold} AUROC={metrics['AUROC']:.3f} AUPRC={metrics['AUPRC']:.3f}")
    out = ensure_dir(Path(cfg.output_dir) / ("demo" if args.demo else "real"))
    with (out / "baseline_metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    summary_rows = []
    for model_name in sorted({str(r["Model"]) for r in rows}):
        model_rows = [r for r in rows if r["Model"] == model_name]
        summary = summarize_folds(model_rows)
        summary_rows.append(
            {
                "Model": model_name,
                **{f"{metric}_mean": values[0] for metric, values in summary.items()},
                **{f"{metric}_sd": values[1] for metric, values in summary.items()},
            }
        )
    with (out / "baseline_summary.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"wrote baseline metrics to {out}")


if __name__ == "__main__":
    main()
