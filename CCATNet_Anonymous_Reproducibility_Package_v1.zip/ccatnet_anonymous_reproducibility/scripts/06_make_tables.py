#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import shutil


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/ccatnet_so2024.yaml")
    parser.parse_args()
    src = Path("results/reference_metrics")
    dst = Path("results/runs/reference_copy")
    dst.mkdir(parents=True, exist_ok=True)
    for file in src.glob("*.csv"):
        shutil.copy2(file, dst / file.name)
    print(f"copied reference metric tables to {dst}")


if __name__ == "__main__":
    main()
