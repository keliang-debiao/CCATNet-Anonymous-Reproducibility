#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ccatnet.config import load_config, ensure_dir
from ccatnet.data import build_preprocessor, load_stackoverflow_csv, make_folds
from ccatnet.metrics import summarize_folds
from ccatnet.train import train_ccatnet


def resolve_dev_path(cfg, demo: bool) -> Path:
    if demo:
        return Path(cfg.raw["data"]["demo_dir"]) / "so_2024_demo.csv"
    return Path(cfg.raw["data"]["development_csv"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/ccatnet_so2024.yaml")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    cfg = load_config(args.config)
    frame = load_stackoverflow_csv(resolve_dev_path(cfg, args.demo), cfg.raw["data"])
    folds = make_folds(frame.label, cfg.raw["data"]["n_splits"], cfg.seed)
    rows = []
    for fold, (tr, va) in enumerate(folds, 1):
        pre = build_preprocessor(frame.frame.iloc[tr])
        x_tr = pre.fit_transform(frame.frame.iloc[tr])
        x_va = pre.transform(frame.frame.iloc[va])
        result = train_ccatnet(
            x_tr,
            frame.label.iloc[tr].to_numpy(),
            frame.country.iloc[tr],
            x_va,
            frame.label.iloc[va].to_numpy(),
            frame.country.iloc[va],
            cfg.raw["model"],
            seed=cfg.raw["data"]["random_seeds"][fold - 1],
        )
        row = {"fold": fold, "threshold": result.threshold, **result.metrics}
        rows.append(row)
        print(f"fold={fold} AUROC={row['AUROC']:.3f} AUPRC={row['AUPRC']:.3f} F1={row['F1']:.3f}")
    out = ensure_dir(Path(cfg.output_dir) / ("demo" if args.demo else "real"))
    with (out / "cv_metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    summary = summarize_folds(rows)
    with (out / "cv_summary.txt").open("w", encoding="utf-8") as f:
        for k, (mean, sd) in summary.items():
            f.write(f"{k}: {mean:.3f} ± {sd:.3f}\n")
    print(f"wrote {out / 'cv_metrics.csv'}")


if __name__ == "__main__":
    main()

