#!/usr/bin/env bash
set -euo pipefail

python scripts/00_make_synthetic_demo.py --out data/processed/demo
python scripts/08_run_baselines.py --config configs/ccatnet_so2024.yaml --demo
python scripts/02_run_cv.py --config configs/ccatnet_so2024.yaml --demo
python scripts/03_train_final_external.py --config configs/ccatnet_so2024.yaml --demo
python scripts/04_ablation.py --config configs/ccatnet_so2024.yaml --demo
python scripts/05_robustness.py --config configs/ccatnet_so2024.yaml --demo
python scripts/06_make_tables.py --config configs/ccatnet_so2024.yaml
