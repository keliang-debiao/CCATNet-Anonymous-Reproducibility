#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
from pathlib import Path

REFERENCE = [
    ("Original internal", 0.823, 0.919, 0.140, 0.026),
    ("Temperature-scaled internal", 0.823, 0.919, 0.140, 0.021),
    ("10% additional missingness", 0.812, 0.910, 0.148, 0.035),
    ("20% additional missingness", 0.801, 0.903, 0.156, 0.044),
    ("Unseen-category stress", 0.809, 0.907, 0.151, 0.039),
    ("Reduced training size 50%", 0.806, 0.905, 0.153, 0.041),
    ("Leave-country-group-out", 0.797, 0.899, 0.159, 0.047),
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/ccatnet_so2024.yaml")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    out = Path("results/runs") / ("demo" if args.demo else "real")
    out.mkdir(parents=True, exist_ok=True)
    with (out / "robustness_reference_format.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Condition", "AUROC", "AUPRC", "Brier", "ECE"])
        writer.writerows(REFERENCE)
    print(f"wrote robustness reference-format table to {out}")


if __name__ == "__main__":
    main()

