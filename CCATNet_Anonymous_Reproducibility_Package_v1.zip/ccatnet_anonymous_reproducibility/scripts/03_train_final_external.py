#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ccatnet.config import load_config, ensure_dir
from ccatnet.data import build_preprocessor, harmonize_frames, load_stackoverflow_csv
from ccatnet.train import train_ccatnet


def resolve_paths(cfg, demo: bool) -> tuple[Path, Path]:
    if demo:
        base = Path(cfg.raw["data"]["demo_dir"])
        return base / "so_2024_demo.csv", base / "so_2025_demo.csv"
    return Path(cfg.raw["data"]["development_csv"]), Path(cfg.raw["data"]["external_csv"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/ccatnet_so2024.yaml")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    cfg = load_config(args.config)
    dev_path, ext_path = resolve_paths(cfg, args.demo)
    dev = load_stackoverflow_csv(dev_path, cfg.raw["data"])
    ext = load_stackoverflow_csv(ext_path, cfg.raw["data"])
    dev, ext = harmonize_frames(dev, ext)
    pre = build_preprocessor(dev.frame)
    x_dev = pre.fit_transform(dev.frame)
    x_ext = pre.transform(ext.frame)
    result = train_ccatnet(
        x_dev,
        dev.label.to_numpy(),
        dev.country,
        x_ext,
        ext.label.to_numpy(),
        ext.country,
        cfg.raw["model"],
        seed=cfg.seed,
    )
    out = ensure_dir(Path(cfg.output_dir) / ("demo" if args.demo else "real"))
    row = {"protocol": "zero_fine_tuning", **result.metrics}
    with (out / "external_metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)
    print("external zero-fine-tuning:", {k: round(v, 3) for k, v in result.metrics.items()})


if __name__ == "__main__":
    main()

