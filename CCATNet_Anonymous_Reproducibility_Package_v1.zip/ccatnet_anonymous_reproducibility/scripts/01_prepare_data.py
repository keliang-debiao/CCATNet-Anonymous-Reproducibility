#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ccatnet.config import load_config, ensure_dir
from ccatnet.data import harmonize_frames, load_stackoverflow_csv


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/ccatnet_so2024.yaml")
    args = parser.parse_args()
    cfg = load_config(args.config)
    data_cfg = cfg.raw["data"]
    dev = load_stackoverflow_csv(data_cfg["development_csv"], data_cfg)
    ext = load_stackoverflow_csv(data_cfg["external_csv"], data_cfg)
    dev, ext = harmonize_frames(dev, ext)
    out = ensure_dir("data/processed/real")
    dev.frame.assign(__label=dev.label, __country=dev.country).to_csv(out / "development.csv", index=False)
    ext.frame.assign(__label=ext.label, __country=ext.country).to_csv(out / "external.csv", index=False)
    pd.Series(dev.feature_columns).to_csv(out / "harmonized_features.csv", index=False, header=["feature"])
    print(f"development analyzable records: {len(dev.label)}")
    print(f"external analyzable records: {len(ext.label)}")
    print(f"harmonized features: {len(dev.feature_columns)}")


if __name__ == "__main__":
    main()
