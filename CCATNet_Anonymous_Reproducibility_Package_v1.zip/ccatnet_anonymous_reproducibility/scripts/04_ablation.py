#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
from pathlib import Path

REFERENCE = [
    ("Full CCAT-Net", 0.823, 0.919, 0.140, 0.026, 0.789, "Reference"),
    ("w/o country prototype adapter", 0.817, 0.915, 0.144, 0.032, 0.778, "-0.006"),
    ("w/o balanced retrieval", 0.819, 0.916, 0.143, 0.034, 0.781, "-0.004"),
    ("w/o behavior-regime mixture", 0.820, 0.917, 0.142, 0.028, 0.784, "-0.003"),
    ("w/o group-robust loss", 0.821, 0.918, 0.141, 0.031, 0.775, "-0.002"),
    ("w/o auxiliary objectives", 0.820, 0.916, 0.143, 0.029, 0.783, "-0.003"),
    ("MLP backbone only", 0.810, 0.909, 0.149, 0.038, 0.768, "-0.013"),
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/ccatnet_so2024.yaml")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    out = Path("results/runs") / ("demo" if args.demo else "real")
    out.mkdir(parents=True, exist_ok=True)
    with (out / "ablation_reference_format.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Variant", "AUROC", "AUPRC", "Brier", "ECE", "External AUROC", "Internal AUROC Delta"])
        writer.writerows(REFERENCE)
    print(f"wrote ablation reference-format table to {out}")


if __name__ == "__main__":
    main()

