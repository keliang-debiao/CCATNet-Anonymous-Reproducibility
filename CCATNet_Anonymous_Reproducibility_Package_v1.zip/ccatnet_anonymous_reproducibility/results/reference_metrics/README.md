# Reference Metric Tables

The CSV files in this directory mirror the numerical tables reported in the manuscript. They are intended as target outputs for reproduction checks and for validating table-generation scripts.

These files are not substitutes for real experiment logs. When the full Kaggle-based reproduction is run, generated outputs should be stored under `results/runs/real/` and compared against these reference tables.
