# Anonymous Review Notes

This repository is prepared for anonymous review.

## Removed or Avoided

- Author names and affiliations.
- Local absolute paths.
- Private account identifiers.
- Raw survey files.
- Institution-specific scripts.

## Data Availability Statement for Repository Use

The repository does not redistribute Stack Overflow survey records. Reviewers can obtain the public datasets from Kaggle using the routes listed in `DATA.md`. The manuscript-level analyzable counts are reproduced after valid AI-use label filtering, harmonized feature intersection, and leakage screening.

## Simulated Logs

The `logs/simulated/` directory contains simulated logs aligned with the manuscript tables. These logs are included to guide automated experiment orchestration and expected output schemas. They should not be described as independent runtime evidence.

## Recommended Anonymous Submission Contents

- Source code and scripts.
- Configuration files.
- Reference metric tables.
- Simulated logs clearly labelled as simulated.
- Documentation files.
- No raw data files.
