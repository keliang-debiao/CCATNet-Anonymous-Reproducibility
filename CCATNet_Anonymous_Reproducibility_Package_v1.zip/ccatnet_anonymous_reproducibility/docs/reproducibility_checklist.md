# Reproducibility Checklist

## Environment

- Python 3.10 or later.
- Install dependencies with `pip install -r requirements.txt` or create the Conda environment from `environment.yml`.
- GPU is optional; the provided scripts default to CPU-compatible execution.

## Synthetic Smoke Run

Run:

```bash
make demo
pytest -q
```

Expected generated files:

- `data/processed/demo/so_2024_demo.csv`
- `data/processed/demo/so_2025_demo.csv`
- `results/runs/demo/cv_metrics.csv`
- `results/runs/demo/cv_summary.txt`
- `results/runs/demo/baseline_metrics.csv`
- `results/runs/demo/baseline_summary.csv`
- `results/runs/demo/external_metrics.csv`
- `results/runs/demo/ablation_reference_format.csv`
- `results/runs/demo/robustness_reference_format.csv`
- `results/runs/reference_copy/*.csv`

## Full Empirical Run

1. Download the 2024 and 2025 Stack Overflow survey CSV files from the Kaggle routes listed in `DATA.md`.
2. Save them as `data/raw/so_2024.csv` and `data/raw/so_2025.csv`, or edit `configs/ccatnet_so2024.yaml`.
3. Run:

```bash
python scripts/01_prepare_data.py --config configs/ccatnet_so2024.yaml
python scripts/08_run_baselines.py --config configs/ccatnet_so2024.yaml
python scripts/02_run_cv.py --config configs/ccatnet_so2024.yaml
python scripts/03_train_final_external.py --config configs/ccatnet_so2024.yaml
python scripts/04_ablation.py --config configs/ccatnet_so2024.yaml
python scripts/05_robustness.py --config configs/ccatnet_so2024.yaml
python scripts/06_make_tables.py --config configs/ccatnet_so2024.yaml
```

## Leakage Controls to Verify

- Label derivation is performed before model fitting.
- Leakage-prone AI-attitude columns are screened before predictor construction.
- Imputation, scaling, category vocabularies, and one-hot encoders are fitted inside each training fold.
- External validation uses preprocessing fitted on the development set only.
- Threshold selection is performed on validation folds or frozen development predictions, not on external labels.

## Log Handling

Files under `logs/simulated/` are simulated examples for expected formatting. Real empirical logs should be saved under `logs/real/` or exported by the execution platform and should replace simulated logs before any claim of independent replication.
